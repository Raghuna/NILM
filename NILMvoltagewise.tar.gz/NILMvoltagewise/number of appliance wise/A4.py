import csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
#get_ipython().magic(u'pylab inline')
import seaborn as sns
from sklearn import svm,cross_validation
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import linear_model
import pywt
from sklearn import decomposition
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.ensemble import RandomForestClassifier
from sklearn.cross_validation import cross_val_score
from sklearn.ensemble import AdaBoostClassifier
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import confusion_matrix
import time

pkmn_type_colors = ['#78C850',  # Grass
                    '#F08030',  # Fire
                    '#6890F0',  # Water
                    '#A8B820',  # Bug
                    '#A8A878',  # Normal
                    '#A040A0',  # Poison
                    '#F8D030',  # Electric
                    '#E0C068',  # Ground
                    '#EE99AC',  # Fairy
                    '#C03028',  # Fighting
                    '#F85888',  # Psychic
                    '#B8A038',  # Rock
                    '#705898',  # Ghost
                    '#98D8D8',  # Ice
                    '#7038F8',  # Dragon
                   ]
nn,cv=10,5
# For .read_csv, always use header=0 when you know row 0 is the header row
df = pd.read_csv('g4.csv')
df = pd.DataFrame(df,columns=['i','p','s','q','pf','phi','Class'])
#print (df.describe())

'''sns.set_style("darkgrid")
sns.countplot(x='Class', data=df)
plt.xticks(rotation=-45)
plt.show()'''

import datetime 

# For .read_csv, always use header=0 when you know row 0 is the header row
df=df.values
train =df[:,:-1]
train = train.astype(np.float)
target=df[:,-1:] 
target = target.astype(np.int)
target=target.T
target=target[0]

#print (train.shape)
#print (target.shape)
#print (train)
#print (target)
t1=datetime.datetime.now()
print (datetime.datetime.now())
print ("KNN crossvalidation :")
knn = KNeighborsClassifier(n_neighbors=nn) 
scores = cross_validation.cross_val_score(knn, train, target, cv=cv) 
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
t2=datetime.datetime.now()
print (t2-t1)

y_pred = cross_val_predict(knn,train,target,cv=10)
conf_mat = confusion_matrix(target,y_pred)
FP = conf_mat.sum(axis=0) - np.diag(conf_mat)  
FN = conf_mat.sum(axis=1) - np.diag(conf_mat)
TP = np.diag(conf_mat)
TN = conf_mat.sum() - (FP + FN + TP)
# Sensitivity, hit rate, recall, or true positive rate
TPR = TP*1.0/(TP+FN)
print ("recall ", TPR.mean())
PPV = TP*1.0/(TP+FP)
print ("precision ", PPV.mean())

t1=datetime.datetime.now()
print ("SVC crossvalidation :")
svc = svm.SVC()
scores = cross_validation.cross_val_score(svc, train, target, cv=cv) 
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2)) 
t2=datetime.datetime.now()
print (t2-t1)
y_pred = cross_val_predict(svc,train,target,cv=10)
conf_mat = confusion_matrix(target,y_pred)
FP = conf_mat.sum(axis=0) - np.diag(conf_mat)  
FN = conf_mat.sum(axis=1) - np.diag(conf_mat)
TP = np.diag(conf_mat)
TN = conf_mat.sum() - (FP + FN + TP)
# Sensitivity, hit rate, recall, or true positive rate
TPR = TP*1.0/(TP+FN)
print ("recall ", TPR.mean())
PPV = TP*1.0/(TP+FP)
print ("precision ", PPV.mean())

t1=datetime.datetime.now()
print ("RF crossvalidation :" )
clf = RandomForestClassifier(n_estimators=10)
scores = cross_validation.cross_val_score(clf, train, target, cv=cv) 
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2)) 
t2=datetime.datetime.now()
print (t2-t1)
y_pred = cross_val_predict(clf,train,target,cv=10)
conf_mat = confusion_matrix(target,y_pred)
FP = conf_mat.sum(axis=0) - np.diag(conf_mat)  
FN = conf_mat.sum(axis=1) - np.diag(conf_mat)
TP = np.diag(conf_mat)
TN = conf_mat.sum() - (FP + FN + TP)
# Sensitivity, hit rate, recall, or true positive rate
TPR = TP*1.0/(TP+FN)
print ("recall ", TPR.mean())
PPV = TP*1.0/(TP+FP)
print ("precision ", PPV.mean())

t1=datetime.datetime.now()
print ("GNB crossvalidation :")
gnb = GaussianNB()
scores = cross_validation.cross_val_score(gnb, train, target, cv=cv) 
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2)) 
t2=datetime.datetime.now()
print (t2-t1)
y_pred = cross_val_predict(gnb,train,target,cv=10)
conf_mat = confusion_matrix(target,y_pred)
FP = conf_mat.sum(axis=0) - np.diag(conf_mat)  
FN = conf_mat.sum(axis=1) - np.diag(conf_mat)
TP = np.diag(conf_mat)
TN = conf_mat.sum() - (FP + FN + TP)
# Sensitivity, hit rate, recall, or true positive rate
TPR = TP*1.0/(TP+FN)
print ("recall ", TPR.mean())
PPV = TP*1.0/(TP+FP)
print ("precision ", PPV.mean())


"""t1=datetime.datetime.now()
print ("Boosting: ") 
clf = AdaBoostClassifier(n_estimators = 200)
scores = cross_val_score(clf,train, target, cv=5)
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
t2=datetime.datetime.now()

sns.set(font_scale=1.4)#for label size
plt.subplots(figsize=(20,15))
sns.heatmap(conf_mat,linewidths=0.1, annot=True, annot_kws={"size":12})# font size
plt.show()"""

t1=datetime.datetime.now()
from sklearn.ensemble import VotingClassifier
from sklearn import model_selection
estimators = []
estimators.append(('knn', knn))
estimators.append(('SVC', svc))
estimators.append(('RF', clf))
# create the ensemble model
ensemble = VotingClassifier(estimators)
scores = model_selection.cross_val_score(ensemble, train, target, cv=cv)
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2)) 
t2=datetime.datetime.now()
print (t2-t1)
