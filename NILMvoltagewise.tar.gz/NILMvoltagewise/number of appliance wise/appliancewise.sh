#!/bin/bash
python -W ignore A3.py  
python -W ignore A4.py 
python -W ignore A5.py 
python -W ignore A6.py 
python -W ignore A7.py 
python -W ignore A8.py 
