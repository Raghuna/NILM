#!/bin/bash
python -W ignore withd.py  
python -W ignore withoutd.py 

