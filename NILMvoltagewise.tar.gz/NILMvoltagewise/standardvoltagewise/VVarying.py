import csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
#get_ipython().magic(u'pylab inline')
import seaborn as sns
from sklearn import svm,cross_validation
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import linear_model
import pywt
from sklearn import decomposition
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.ensemble import RandomForestClassifier
from sklearn.cross_validation import cross_val_score
from sklearn.ensemble import AdaBoostClassifier
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import confusion_matrix
import time

nn,cv=10,5
# For .read_csv, always use header=0 when you know row 0 is the header row

df = pd.read_csv('vvtrain1.csv')
df=df.values
trainData = df[:,:-1]
trainData = trainData.astype(np.float)
trainTarget = df[:,-1:]
trainTarget = trainTarget.astype(np.int)
trainTarget=trainTarget.T
trainTarget=trainTarget[0]

df = pd.read_csv('vvtest1.csv')
df=df.values
testData = df[:,:-1]
testData = testData.astype(np.float)
testTarget = df[:,-1:] 
testTarget = testTarget.astype(np.int)
testTarget=testTarget.T[0]


knn = KNeighborsClassifier(n_neighbors=3) 
print ("on test:",knn.fit(trainData, trainTarget).score(testData, testTarget))


svc = svm.SVC()
y_pred = svc.fit(trainData, trainTarget).predict(testData)
print ("on test:",svc.fit(trainData, trainTarget).score(testData, testTarget))
cm = confusion_matrix(testTarget, y_pred)
print (cm)


gnb = GaussianNB()
print (gnb.fit(trainData, trainTarget).score(testData, testTarget))

from sklearn.ensemble import RandomForestClassifier
clf = RandomForestClassifier(n_estimators=10)
print (clf.fit(trainData, trainTarget).score(testData, testTarget))

from sklearn.ensemble import VotingClassifier
from sklearn import model_selection
estimators = []
estimators.append(('knn', knn))
estimators.append(('SVC', svc))
estimators.append(('RF', clf))
# create the ensemble model
ensemble = VotingClassifier(estimators)
print (ensemble.fit(trainData, trainTarget).score(testData, testTarget))










