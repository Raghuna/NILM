#!/bin/bash
python -W ignore VVarying.py 
python -W ignore Vfixed.py 

