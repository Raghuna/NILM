#!/bin/bash
python -W ignore s10.py  
python -W ignore s20.py 
python -W ignore s30.py 
python -W ignore s40.py 
python -W ignore s50.py 
python -W ignore s60.py 
